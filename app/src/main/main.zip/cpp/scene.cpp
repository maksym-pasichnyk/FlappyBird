#include "scene.h"

std::vector<GameObject*> Scene::gameObjects;