#include "ninepath.h"

Ninepath::Ninepath(Texture2D texture, float left, float right, float bottom, float top) {
	Ninepath::texture = texture;
	Ninepath::left = left;
	Ninepath::right = right;
	Ninepath::bottom = bottom;
	Ninepath::top = top;
}